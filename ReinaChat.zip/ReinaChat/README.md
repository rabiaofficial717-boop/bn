# 🎮 Reina Chat - Android Jetpack Compose

A stunning mobile chat application featuring **Reina** – your stylish, confident AI companion with a bold gaming-inspired attitude!

![Reina Chat](https://img.shields.io/badge/Platform-Android-green?style=for-the-badge)
![Kotlin](https://img.shields.io/badge/Kotlin-1.9.20-purple?style=for-the-badge)
![Jetpack Compose](https://img.shields.io/badge/Jetpack_Compose-Material3-blue?style=for-the-badge)

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🎬 **Animated Welcome Screen** | Stunning neon effects with floating particles |
| 💬 **Live Chat** | Real-time chat with typewriter effect responses |
| 🎮 **Gaming-Style Credits** | Limited messages that encourage engagement |
| 📺 **Watch Ads for More** | Rewarded ads (AdMob) to earn 5 more credits |
| 👑 **Premium Option** | Unlimited chatting (ready for billing integration) |
| 📴 **Works Offline** | Smart AI responses without internet |
| 📱 **Mobile First** | Touch-friendly design optimized for phones |

## 🎨 Design

- **Dark Theme** with purple/pink neon accents
- **Glassmorphism** effects (frosted glass look)
- **Gaming aesthetic** inspired by GTA and Tekken menus
- **Smooth Animations** throughout the experience

## 💰 Monetization System

1. Users start with **10 credits**
2. Each message costs **3 credits**
3. When credits hit 0, a stylish popup appears:
   - 📺 Watch Ad → Get 5 more credits (free)
   - 👑 Go Premium → Unlimited credits (paid upgrade)

## 🛠️ Tech Stack

- **Kotlin** 1.9.20
- **Jetpack Compose** with Material 3
- **MVVM Architecture** with StateFlow
- **Navigation Compose**
- **DataStore** for persistence
- **AdMob** for rewarded ads
- **Lottie** for animations
- **Coil** for images

## 📁 Project Structure

```
ReinaChat/
├── app/
│   ├── src/main/
│   │   ├── java/com/reina/chat/
│   │   │   ├── MainActivity.kt          # Entry point
│   │   │   ├── ReinaChatApp.kt          # Application class
│   │   │   ├── data/
│   │   │   │   ├── ChatMessage.kt       # Data models
│   │   │   │   ├── CreditsManager.kt    # Credits persistence
│   │   │   │   ├── AdManager.kt         # AdMob integration
│   │   │   │   └── ReinaAI.kt           # AI response generator
│   │   │   ├── viewmodel/
│   │   │   │   └── ChatViewModel.kt     # Main ViewModel
│   │   │   └── ui/
│   │   │       ├── theme/               # Colors, Typography, Theme
│   │   │       ├── components/          # Reusable UI components
│   │   │       └── screens/             # Welcome & Chat screens
│   │   ├── res/
│   │   │   ├── values/                  # Colors, Strings, Themes
│   │   │   └── drawable/                # Icons and graphics
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## 🚀 Getting Started

### Prerequisites

- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Kotlin 1.9.20
- JDK 17

### Build Instructions

1. **Open in Android Studio**
   ```
   Open D:\ReinaChat in Android Studio
   ```

2. **Sync Gradle**
   - Click "Sync Now" when prompted
   - Or: File → Sync Project with Gradle Files

3. **Run on Device/Emulator**
   - Select a device (API 24+)
   - Click Run (▶️)

### Build APK

```bash
# Debug APK
./gradlew assembleDebug

# Release APK
./gradlew assembleRelease
```

APK will be in: `app/build/outputs/apk/`

## 🔧 Configuration

### AdMob Setup

1. Replace the test App ID in `AndroidManifest.xml`:
   ```xml
   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="YOUR_ADMOB_APP_ID"/>
   ```

2. Replace the test Ad Unit ID in `AdManager.kt`:
   ```kotlin
   private const val AD_UNIT_ID = "YOUR_AD_UNIT_ID"
   ```

### Premium/Billing Integration

The app is ready for Google Play Billing integration. The `purchasePremium()` function in `ChatViewModel.kt` is where you'd add:

```kotlin
// Add Google Play Billing Library
implementation("com.android.billingclient:billing-ktx:6.1.0")
```

## 🎮 Reina's Personality

Reina responds differently based on:
- **Greetings** - Enthusiastic welcomes
- **Emotions** - Supportive responses for sad, happy, stressed, etc.
- **Gaming** - Gets excited about games
- **Music** - Loves music discussions
- **Jokes** - Has a collection of puns
- **Advice** - Offers helpful suggestions

## 📝 License

This project is created for educational purposes.

## 🤝 Contributing

Feel free to submit issues and enhancement requests!

---

Made with 💜 and ⚡ Neon Energy
