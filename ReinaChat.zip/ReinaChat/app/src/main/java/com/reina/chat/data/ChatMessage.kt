package com.reina.chat.data

import java.util.UUID

/**
 * Represents a single chat message in the conversation
 */
data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val isFromUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isTyping: Boolean = false
)

/**
 * Represents Reina's personality and response style
 */
object ReinaPersonality {
    const val NAME = "Reina"
    
    val greetings = listOf(
        "Hey there, player! 💜 Ready to chat with the one and only Reina?",
        "Yo! You finally showed up. I was getting bored. 😏",
        "Welcome to my domain! Let's make this interesting. ✨",
        "Sup! You've unlocked the best conversation partner in the game. 🎮"
    )
    
    val responses = listOf(
        "Hah, interesting take! But have you considered that %s? Just saying. 💁‍♀️",
        "Okay okay, I see you! That's actually pretty cool. 🔥",
        "Hmm, bold move saying that to me. I respect it though! 💜",
        "You're not wrong, but you're not entirely right either. Let me explain... 🎯",
        "That's giving main character energy and I'm here for it! ✨",
        "Ooh, spicy! I like where this is going. 🌶️",
        "Real talk? That's actually a vibe. 💯",
        "See, THIS is why I keep you around. Good point! 👏",
        "Nah, I'm gonna have to disagree there. Fight me! 😤",
        "You really said that with your whole chest huh? Respect. 💪"
    )
    
    val lowCreditsWarning = listOf(
        "Hey, running low on credits! Don't leave me hanging... 💔",
        "Uh oh, we're almost out of time together! Quick, get more credits! ⏰",
        "Credits getting low... You're not gonna ghost me, right? 👀"
    )
    
    val outOfCreditsMessage = "Aww man, you're out of credits! 😢 Watch a quick ad or go premium to keep chatting with me!"
    
    fun getRandomGreeting(): String = greetings.random()
    
    fun generateResponse(userMessage: String): String {
        val baseResponse = responses.random()
        val additions = listOf(
            "\n\nAnyway, what else is on your mind?",
            "\n\nKeep 'em coming, I'm just getting warmed up!",
            "\n\nYour turn! 🎮",
            "",
            ""
        )
        return baseResponse.replace("%s", "maybe you haven't seen the bigger picture") + additions.random()
    }
}
