package com.reina.chat.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.reina.chat.ui.theme.*

/**
 * Stylish credits modal with gaming aesthetic
 * Shows when user runs out of credits
 */
@Composable
fun CreditsModal(
    visible: Boolean,
    onDismiss: () -> Unit,
    onWatchAd: () -> Unit,
    onGoPremium: () -> Unit,
    isAdReady: Boolean = true
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(animationSpec = tween(300)),
        exit = fadeOut(animationSpec = tween(300))
    ) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = true,
                usePlatformDefaultWidth = false
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center
            ) {
                // Modal content
                CreditsModalContent(
                    onDismiss = onDismiss,
                    onWatchAd = onWatchAd,
                    onGoPremium = onGoPremium,
                    isAdReady = isAdReady,
                    modifier = Modifier.clickable(enabled = false) { }
                )
            }
        }
    }
}

@Composable
private fun CreditsModalContent(
    onDismiss: () -> Unit,
    onWatchAd: () -> Unit,
    onGoPremium: () -> Unit,
    isAdReady: Boolean,
    modifier: Modifier = Modifier
) {
    // Animated border
    val infiniteTransition = rememberInfiniteTransition(label = "modal_glow")
    val borderProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "border"
    )
    
    Column(
        modifier = modifier
            .width(320.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DarkSurface.copy(alpha = 0.98f),
                        DarkSurfaceVariant.copy(alpha = 0.95f)
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.sweepGradient(
                    0f to NeonPink.copy(alpha = 0.3f),
                    borderProgress to NeonPurple,
                    (borderProgress + 0.2f).coerceAtMost(1f) to NeonPink,
                    1f to NeonPink.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Close button
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.TopEnd
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = TextMuted
                )
            }
        }
        
        // Animated emoji
        val scale by infiniteTransition.animateFloat(
            initialValue = 1f,
            targetValue = 1.1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, easing = EaseInOutSine),
                repeatMode = RepeatMode.Reverse
            ),
            label = "emoji_scale"
        )
        
        Text(
            text = "😢",
            fontSize = (48 * scale).sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        
        Text(
            text = "Out of Credits!",
            color = TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Text(
            text = "Keep the conversation going with Reina",
            color = TextSecondary,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Watch Ad Button
        GradientButton(
            text = "Watch Ad",
            subtext = "+5 Credits",
            icon = Icons.Default.PlayArrow,
            gradient = listOf(NeonPurple, NeonPink),
            onClick = onWatchAd,
            enabled = isAdReady,
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        // Go Premium Button
        GradientButton(
            text = "Go Premium",
            subtext = "Unlimited ∞",
            icon = Icons.Default.Star,
            gradient = listOf(Color(0xFFFFD700), Color(0xFFFF8C00)),
            onClick = onGoPremium,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Premium upgrade modal
 */
@Composable
fun PremiumModal(
    visible: Boolean,
    onDismiss: () -> Unit,
    onPurchase: () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(animationSpec = tween(300)) + scaleIn(initialScale = 0.9f),
        exit = fadeOut(animationSpec = tween(300)) + scaleOut(targetScale = 0.9f)
    ) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = true,
                usePlatformDefaultWidth = false
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.7f))
                    .clickable(onClick = onDismiss),
                contentAlignment = Alignment.Center
            ) {
                PremiumModalContent(
                    onDismiss = onDismiss,
                    onPurchase = onPurchase,
                    modifier = Modifier.clickable(enabled = false) { }
                )
            }
        }
    }
}

@Composable
private fun PremiumModalContent(
    onDismiss: () -> Unit,
    onPurchase: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "premium_glow")
    val shimmer by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )
    
    Column(
        modifier = modifier
            .width(320.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DarkSurface,
                        Color(0xFF1a1a2e)
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.sweepGradient(
                    0f to Color(0xFFFFD700).copy(alpha = 0.3f),
                    shimmer to Color(0xFFFFD700),
                    (shimmer + 0.3f).coerceAtMost(1f) to Color(0xFFFF8C00),
                    1f to Color(0xFFFFD700).copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Close button
        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.TopEnd
        ) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = TextMuted
                )
            }
        }
        
        Text(
            text = "👑",
            fontSize = 56.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        
        Text(
            text = "Unlock Premium",
            color = Color(0xFFFFD700),
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        // Benefits list
        PremiumBenefit("Unlimited messages with Reina")
        PremiumBenefit("No ads ever")
        PremiumBenefit("Priority responses")
        PremiumBenefit("Exclusive personality modes")
        
        Spacer(modifier = Modifier.height(24.dp))
        
        // Purchase button
        GradientButton(
            text = "Upgrade Now",
            subtext = "$4.99/month",
            icon = Icons.Default.Star,
            gradient = listOf(Color(0xFFFFD700), Color(0xFFFF8C00)),
            onClick = onPurchase,
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Text(
            text = "Cancel anytime",
            color = TextMuted,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun PremiumBenefit(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "✨",
            fontSize = 16.sp,
            modifier = Modifier.padding(end = 12.dp)
        )
        Text(
            text = text,
            color = TextSecondary,
            fontSize = 14.sp
        )
    }
}

/**
 * Reusable gradient button with icon
 */
@Composable
fun GradientButton(
    text: String,
    subtext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    gradient: List<Color>,
    onClick: () -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(56.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (enabled) {
                    Brush.linearGradient(gradient)
                } else {
                    Brush.linearGradient(listOf(Color.Gray, Color.DarkGray))
                }
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (enabled) Color.White else Color.LightGray,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = text,
                    color = if (enabled) Color.White else Color.LightGray,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtext,
                    color = if (enabled) Color.White.copy(alpha = 0.8f) else Color.LightGray,
                    fontSize = 12.sp
                )
            }
        }
    }
}
