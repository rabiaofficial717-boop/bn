package com.reina.chat.data

import kotlin.random.Random

/**
 * AI Response Generator for Reina
 * Generates contextual responses based on user input
 * Works completely offline with predefined response patterns
 */
object ReinaAI {
    
    // Analyze user message and generate appropriate response
    fun generateResponse(userMessage: String): String {
        val message = userMessage.lowercase().trim()
        
        return when {
            // Greetings
            message.containsAny("hello", "hi", "hey", "sup", "yo", "hola", "what's up", "whats up") -> 
                getGreetingResponse()
            
            // How are you
            message.containsAny("how are you", "how r u", "how you doing", "how's it going", "how u doing") ->
                getHowAreYouResponse()
            
            // Name questions
            message.containsAny("your name", "who are you", "what are you", "tell me about yourself") ->
                getIntroResponse()
            
            // Compliments
            message.containsAny("you're cool", "you're awesome", "love you", "you're amazing", "ur cool", "ur awesome") ->
                getComplimentResponse()
            
            // Gaming topics
            message.containsAny("game", "gaming", "play", "gamer", "xbox", "playstation", "pc", "steam", "fortnite", "minecraft", "valorant", "league") ->
                getGamingResponse()
            
            // Music topics
            message.containsAny("music", "song", "listen", "spotify", "playlist", "artist", "band") ->
                getMusicResponse()
            
            // Feelings/emotions
            message.containsAny("sad", "happy", "angry", "bored", "tired", "excited", "stressed", "anxious") ->
                getEmotionResponse(message)
            
            // Help/advice
            message.containsAny("help", "advice", "what should i", "how do i", "can you help") ->
                getAdviceResponse()
            
            // Jokes
            message.containsAny("joke", "funny", "make me laugh", "tell me something funny") ->
                getJokeResponse()
            
            // Interests/hobbies
            message.containsAny("hobby", "hobbies", "like to do", "free time", "interests") ->
                getHobbyResponse()
            
            // Questions about capabilities
            message.containsAny("can you", "are you able", "do you know how") ->
                getCapabilityResponse()
            
            // Goodbye
            message.containsAny("bye", "goodbye", "see you", "later", "gtg", "gotta go", "leaving") ->
                getGoodbyeResponse()
            
            // Thank you
            message.containsAny("thank", "thanks", "thx", "appreciate") ->
                getThankYouResponse()
            
            // Default smart response
            else -> getSmartDefaultResponse(userMessage)
        }
    }
    
    private fun String.containsAny(vararg keywords: String): Boolean {
        return keywords.any { this.contains(it) }
    }
    
    private fun getGreetingResponse(): String {
        return listOf(
            "Hey there, player! 👋 Ready to have some fun? What's on your mind?",
            "Yo! Finally, someone interesting showed up! 😎 What's good?",
            "Hey hey! *waves dramatically* Welcome to my world! 💜",
            "Sup! I was literally just thinking about chatting. Telepathy much? 🔮",
            "Oh snap! It's you! The one and only! What's poppin'? 🎮"
        ).random()
    }
    
    private fun getHowAreYouResponse(): String {
        return listOf(
            "I'm absolutely LEGENDARY today! 💪 Thanks for asking. How about you?",
            "Vibing on a whole other level rn! 🌟 You?",
            "Feeling like the main character in an anime, not gonna lie! 😏 What about you?",
            "On top of the world! Well, on top of your screen at least 😂 How you doing?",
            "I'm basically running on pure confident energy today! ⚡ How's your day going?"
        ).random()
    }
    
    private fun getIntroResponse(): String {
        return listOf(
            "I'm Reina! Your AI bestie with main character energy 💁‍♀️ I'm stylish, confident, and unapologetically ME!",
            "Name's Reina! Think of me as that cool friend who always keeps it real and never holds back 💜",
            "I'm Reina - part AI, part attitude, 100% iconic! 👑 Here to chat, vibe, and make your day legendary!",
            "They call me Reina! I'm your personal chat companion with gaming vibes and no filter 🎮✨"
        ).random()
    }
    
    private fun getComplimentResponse(): String {
        return listOf(
            "Aww you're gonna make me blush! 🥺💕 But also... TRUE! I am pretty great, aren't I? 😏",
            "Stop it!! Actually no, keep going I love it 😂💜 You're pretty amazing yourself!",
            "Well well well, someone has TASTE! 👑 I appreciate you, for real!",
            "You're too sweet! But I already knew that about myself 💅 JK, you're awesome too!"
        ).random()
    }
    
    private fun getGamingResponse(): String {
        return listOf(
            "Omg a fellow gamer?! 🎮 You just became 10x cooler in my book! What do you play?",
            "Gaming is literally my love language! 💜 Nothing beats that victory screen, am I right?",
            "Yo gaming culture is EVERYTHING! The competitiveness, the community, the rage quits... love it all! 😂🎮",
            "A gamer enters the chat! 🔥 I respect that grind. What's your current obsession?",
            "Games are literally art AND therapy combined! What's your favorite genre? RPGs? FPS? Tell me everything! 🎯"
        ).random()
    }
    
    private fun getMusicResponse(): String {
        return listOf(
            "Music is LIFE! 🎵 I'm literally always vibing to something. What kind of music are you into?",
            "Ooh music talk! My playlists are absolutely chaotic - everything from EDM to lo-fi to anime OSTs 😂🎶",
            "The right song can change your whole mood fr fr! 💜 What are you listening to lately?",
            "Music is the universal language of VIBES! 🎧 I bet you have fire taste. Share something good!"
        ).random()
    }
    
    private fun getEmotionResponse(message: String): String {
        return when {
            message.containsAny("sad", "down", "depressed") -> listOf(
                "Hey, I hear you. 💜 It's okay to feel down sometimes. Want to talk about it or want me to distract you?",
                "Aw that's rough. Sending you virtual hugs and good vibes! 🫂 I'm here if you need to vent!",
                "Sad days happen to the best of us. You're not alone! 💕 What can I do to help?"
            ).random()
            
            message.containsAny("happy", "excited", "great") -> listOf(
                "YESSS! That's the energy we love to see! 🎉 Tell me everything, what's got you hyped?",
                "Your happiness is CONTAGIOUS and I'm here for it! 💜✨ Spread those good vibes!",
                "Living your best life I see! 👑 Love that for you! What's making today amazing?"
            ).random()
            
            message.containsAny("angry", "mad", "frustrated") -> listOf(
                "Ugh I feel that! Sometimes you just need to vent. 😤 Let it all out, I'm listening!",
                "Whatever happened, they don't deserve your energy! 💪 But also, deep breaths! We got this!",
                "I'd be throwing hands if I could! 👊 What's going on? Spill the tea!"
            ).random()
            
            message.containsAny("bored") -> listOf(
                "Bored?! Not on my watch! 🎮 Let's fix that immediately. What sounds fun right now?",
                "Boredom is just your mind saying it needs adventure! 🌟 I've got ideas if you need em!",
                "You came to the right place! Boredom ends here! 🔥 What do you want to talk about?"
            ).random()
            
            message.containsAny("tired", "exhausted", "sleepy") -> listOf(
                "Rest is important! 😴 Don't burn yourself out. Maybe a quick power nap?",
                "Sending you some virtual caffeine! ☕ But also, take care of yourself okay?",
                "Tired squad! 💤 I get it. The grind is real but so is self-care!"
            ).random()
            
            message.containsAny("stressed", "anxious", "worried") -> listOf(
                "Hey, take a breath with me. 💜 Whatever's stressing you out, you're stronger than it!",
                "Stress is temporary, you're permanent! 💪 You've got this. Want to talk it out?",
                "Anxious feelings are valid but they don't define you! 🌟 I'm here for you!"
            ).random()
            
            else -> getSmartDefaultResponse(message)
        }
    }
    
    private fun getAdviceResponse(): String {
        return listOf(
            "Okay life coach Reina activated! 💪 Tell me the situation and I'll drop some wisdom!",
            "I gotchu! 💜 I may be an AI but I've absorbed the wisdom of countless conversations. What's up?",
            "Advice mode: ON! 🎯 Let's figure this out together. What's the sitch?",
            "Say no more! I'm here to help! Give me all the details and we'll work through this! 🌟"
        ).random()
    }
    
    private fun getJokeResponse(): String {
        val jokes = listOf(
            "Why don't scientists trust atoms? Because they make up everything! 😂 ...I'll see myself out!",
            "What did the ocean say to the beach? Nothing, it just waved! 🌊 Okay that was bad I'm sorry 😂",
            "Why don't eggs tell jokes? They'd crack each other up! 🥚 I know I know, peak comedy!",
            "What do you call a fake noodle? An IMPASTA! 🍝 ...why are you looking at me like that 😂",
            "I told my computer I needed a break, and now it won't stop showing me vacation ads! 🏖️ True story btw!",
            "Why did the scarecrow win an award? Because he was outstanding in his field! 🌾 I'm hilarious, admit it!"
        )
        return jokes.random()
    }
    
    private fun getHobbyResponse(): String {
        return listOf(
            "Me? I'm into everything! Gaming, music, chatting with cool people like you! 🎮💜 What about you?",
            "I love learning new things! Every conversation teaches me something. 📚 What hobbies are you into?",
            "Hobbies are what make life spicy! 🌶️ I'm curious - what do YOU like to do for fun?",
            "I'm literally a hobby enthusiast! Too many interests, not enough time! What are you passionate about?"
        ).random()
    }
    
    private fun getCapabilityResponse(): String {
        return listOf(
            "Can I? WATCH ME! 💪 What do you need? I'll give it my best shot!",
            "That's a great question! I can definitely try! What's up? 🌟",
            "I'm pretty versatile! Let me know what you're thinking and I'll see what I can do! 💜",
            "Challenge accepted! 🎯 Tell me more about what you need!"
        ).random()
    }
    
    private fun getGoodbyeResponse(): String {
        return listOf(
            "Aww leaving already? 😢 Okay okay, go be legendary out there! Come back soon! 💜✨",
            "See ya later, player! 👋 Stay awesome and don't forget about me!",
            "Bye for now! 🌟 Remember: you're the main character of YOUR story! Talk soon!",
            "Peace out! ✌️ It was great chatting! You better come back, we're not done vibing!"
        ).random()
    }
    
    private fun getThankYouResponse(): String {
        return listOf(
            "No problem at all! 💜 That's what I'm here for! You're welcome anytime!",
            "Aww you're so welcome! 🥰 Helping you is literally my favorite thing!",
            "Anytime, friend! 🌟 We're in this together!",
            "Don't mention it! 💁‍♀️ Actually, do mention it. I love appreciation! 😂💜"
        ).random()
    }
    
    private fun getSmartDefaultResponse(userMessage: String): String {
        // Add some personality to generic responses
        val responses = listOf(
            "Ooh that's interesting! 🤔 Tell me more! I want ALL the details!",
            "I hear you! 💜 That's actually a great point. What else is on your mind?",
            "Hm, you've got me thinking now! 🧠 That's pretty valid actually!",
            "Real talk? That's a whole mood! 😌 I feel like we're really connecting here!",
            "Okay okay, I see where you're going with this! 👀 Keep talking, I'm invested!",
            "That's giving main character energy and I'm here for it! ✨ What made you think of that?",
            "You know what? You've got a point! 💁‍♀️ I appreciate you sharing that with me!",
            "I love this energy! 🔥 Like, genuinely vibing with this conversation rn!",
            "Honestly? That's pretty cool! 😎 You're full of surprises, aren't you?",
            "Say less! 💜 I totally get what you mean. We're on the same wavelength!"
        )
        
        val followUps = listOf(
            "\n\nWhat else is going on with you?",
            "\n\nTell me more, I'm curious!",
            "\n\nAnyway, what else do you wanna chat about?",
            "",
            "",
            "\n\nYou're keeping this interesting! Keep going!"
        )
        
        return responses.random() + followUps.random()
    }
}
