package com.reina.chat.ui.screens

import android.app.Activity
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.reina.chat.ui.components.*
import com.reina.chat.ui.theme.*
import com.reina.chat.viewmodel.ChatViewModel
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

/**
 * Main chat screen with all the gaming aesthetics
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val messages by viewModel.messages.collectAsState()
    val credits by viewModel.credits.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val isTyping by viewModel.isTyping.collectAsState()
    val showCreditsModal by viewModel.showCreditsModal.collectAsState()
    val showPremiumModal by viewModel.showPremiumModal.collectAsState()
    val adError by viewModel.adError.collectAsState()
    
    val context = LocalContext.current
    val activity = context as? Activity
    
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    
    // Scroll to bottom when new messages arrive
    LaunchedEffect(messages.size, isTyping) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1 + if (isTyping) 1 else 0)
        }
    }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Animated background
        AnimatedChatBackground()
        
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top bar
            ChatTopBar(
                credits = credits,
                isPremium = isPremium,
                onPremiumClick = { viewModel.showPremiumUpgrade() }
            )
            
            // Messages list
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(
                    items = messages,
                    key = { it.id }
                ) { message ->
                    ChatBubble(message = message)
                }
                
                // Typing indicator
                if (isTyping) {
                    item {
                        TypingIndicator()
                    }
                }
            }
            
            // Input area
            MessageInput(
                value = inputText,
                onValueChange = { inputText = it },
                onSend = {
                    viewModel.sendMessage(inputText)
                    inputText = ""
                },
                enabled = !isTyping
            )
        }
        
        // Error toast
        AnimatedVisibility(
            visible = adError != null,
            enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            ErrorToast(
                message = adError ?: "",
                modifier = Modifier.padding(top = 100.dp)
            )
        }
        
        // Credits Modal
        CreditsModal(
            visible = showCreditsModal,
            onDismiss = { viewModel.dismissCreditsModal() },
            onWatchAd = {
                activity?.let { viewModel.watchAd(it) }
            },
            onGoPremium = { viewModel.showPremiumUpgrade() },
            isAdReady = viewModel.isAdReady()
        )
        
        // Premium Modal
        PremiumModal(
            visible = showPremiumModal,
            onDismiss = { viewModel.dismissPremiumModal() },
            onPurchase = { viewModel.purchasePremium() }
        )
    }
}

/**
 * Top bar with title and credits display
 */
@Composable
private fun ChatTopBar(
    credits: Int,
    isPremium: Boolean,
    onPremiumClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "topbar")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )
    
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DarkBackground,
                        DarkBackground.copy(alpha = 0.95f),
                        Color.Transparent
                    )
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Title with Reina avatar
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mini avatar
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    NeonPink.copy(alpha = glowAlpha),
                                    NeonPurple.copy(alpha = glowAlpha * 0.8f)
                                )
                            ),
                            shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)
                        )
                        .padding(2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                DarkSurface,
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "R",
                            color = NeonPink,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(modifier = Modifier.width(12.dp))
                
                Column {
                    Text(
                        text = "Reina",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(
                                    SuccessGreen,
                                    shape = androidx.compose.foundation.shape.CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Online",
                            color = SuccessGreen,
                            fontSize = 12.sp
                        )
                    }
                }
            }
            
            // Credits or Premium badge
            if (isPremium) {
                PremiumBadge(onClick = onPremiumClick)
            } else {
                CreditsDisplay(
                    credits = credits,
                    isPremium = false
                )
            }
        }
    }
}

/**
 * Premium badge with crown
 */
@Composable
private fun PremiumBadge(onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "premium")
    val shimmer by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer"
    )
    
    Surface(
        onClick = onClick,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        color = Color.Transparent,
        modifier = Modifier
            .background(
                Brush.linearGradient(
                    0f to Color(0xFFFFD700).copy(alpha = 0.2f),
                    shimmer to Color(0xFFFFD700).copy(alpha = 0.5f),
                    1f to Color(0xFFFFD700).copy(alpha = 0.2f)
                ),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "👑", fontSize = 14.sp)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "PREMIUM",
                color = Color(0xFFFFD700),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Animated background for chat
 */
@Composable
private fun AnimatedChatBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "chat_bg")
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(30000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "bg_offset"
    )
    
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .blur(100.dp)
            .alpha(0.4f)
    ) {
        // Subtle purple orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonPurple.copy(alpha = 0.3f),
                    Color.Transparent
                ),
                center = Offset(
                    x = size.width * 0.2f + cos(Math.toRadians(offset.toDouble())).toFloat() * 50f,
                    y = size.height * 0.3f
                ),
                radius = size.width * 0.4f
            ),
            center = Offset(
                x = size.width * 0.2f + cos(Math.toRadians(offset.toDouble())).toFloat() * 50f,
                y = size.height * 0.3f
            ),
            radius = size.width * 0.4f
        )
        
        // Subtle pink orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonPink.copy(alpha = 0.2f),
                    Color.Transparent
                ),
                center = Offset(
                    x = size.width * 0.8f,
                    y = size.height * 0.7f + sin(Math.toRadians(offset.toDouble())).toFloat() * 30f
                ),
                radius = size.width * 0.35f
            ),
            center = Offset(
                x = size.width * 0.8f,
                y = size.height * 0.7f + sin(Math.toRadians(offset.toDouble())).toFloat() * 30f
            ),
            radius = size.width * 0.35f
        )
    }
}

/**
 * Error toast component
 */
@Composable
private fun ErrorToast(
    message: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(horizontal = 24.dp)
            .background(
                ErrorRed.copy(alpha = 0.9f),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = message,
            color = TextPrimary,
            fontSize = 14.sp
        )
    }
}
