package com.reina.chat.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Neon Colors
val NeonPurple = Color(0xFF9B59FF)
val NeonPink = Color(0xFFFF59E6)
val NeonBlue = Color(0xFF00D4FF)
val NeonCyan = Color(0xFF00FFFF)
val NeonMagenta = Color(0xFFFF00FF)

// Background Colors
val DarkBackground = Color(0xFF0D0D1A)
val DarkSurface = Color(0xFF1A1A2E)
val DarkSurfaceVariant = Color(0xFF16213E)
val GlassSurface = Color(0x331A1A2E)
val GlassOverlay = Color(0x66000000)

// Text Colors
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xCCFFFFFF)
val TextMuted = Color(0x99FFFFFF)

// Gradient Colors
val GradientPurplePink = listOf(NeonPurple, NeonPink)
val GradientPinkBlue = listOf(NeonPink, NeonBlue)
val GradientCyanMagenta = listOf(NeonCyan, NeonMagenta)

// Chat Colors
val UserBubbleColor = NeonPurple.copy(alpha = 0.3f)
val ReinaBubbleColor = NeonPink.copy(alpha = 0.2f)

// Status Colors
val SuccessGreen = Color(0xFF00FF88)
val WarningOrange = Color(0xFFFF9500)
val ErrorRed = Color(0xFFFF3B5C)
