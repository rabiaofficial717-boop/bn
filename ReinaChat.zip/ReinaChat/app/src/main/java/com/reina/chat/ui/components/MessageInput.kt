package com.reina.chat.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reina.chat.ui.theme.*

/**
 * Message input field with glassmorphism styling and neon accent
 */
@Composable
fun MessageInput(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }
    
    // Animated border glow
    val infiniteTransition = rememberInfiniteTransition(label = "input_glow")
    val glowProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "glow_progress"
    )
    
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            DarkSurface.copy(alpha = 0.9f),
                            DarkSurfaceVariant.copy(alpha = 0.7f)
                        )
                    )
                )
                .border(
                    width = 1.5.dp,
                    brush = Brush.sweepGradient(
                        0f to NeonPurple.copy(alpha = 0.3f),
                        glowProgress to NeonPink.copy(alpha = 0.8f),
                        (glowProgress + 0.3f).coerceAtMost(1f) to NeonPurple.copy(alpha = 0.3f),
                        1f to NeonPurple.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(28.dp)
                )
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Text input
            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = "Type your message...",
                        color = TextMuted,
                        fontSize = 15.sp
                    )
                }
                
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    enabled = enabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    textStyle = TextStyle(
                        color = TextPrimary,
                        fontSize = 15.sp
                    ),
                    cursorBrush = SolidColor(NeonPink),
                    singleLine = false,
                    maxLines = 4
                )
            }
            
            // Send button
            IconButton(
                onClick = {
                    if (value.isNotBlank()) {
                        onSend()
                    }
                },
                enabled = enabled && value.isNotBlank(),
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        if (value.isNotBlank()) {
                            Brush.linearGradient(listOf(NeonPurple, NeonPink))
                        } else {
                            Brush.linearGradient(
                                listOf(
                                    DarkSurfaceVariant,
                                    DarkSurfaceVariant
                                )
                            )
                        }
                    )
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (value.isNotBlank()) TextPrimary else TextMuted,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/**
 * Credits display badge with neon styling
 */
@Composable
fun CreditsDisplay(
    credits: Int,
    isPremium: Boolean,
    modifier: Modifier = Modifier
) {
    // Pulsing animation when low credits
    val infiniteTransition = rememberInfiniteTransition(label = "credits_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )
    
    val isLowCredits = credits <= 3 && !isPremium
    
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (isPremium) {
                    Brush.linearGradient(
                        listOf(
                            Color(0xFFFFD700).copy(alpha = 0.3f),
                            Color(0xFFFF8C00).copy(alpha = 0.2f)
                        )
                    )
                } else {
                    Brush.linearGradient(
                        listOf(
                            NeonPurple.copy(alpha = if (isLowCredits) pulseAlpha * 0.4f else 0.3f),
                            NeonPink.copy(alpha = if (isLowCredits) pulseAlpha * 0.3f else 0.2f)
                        )
                    )
                }
            )
            .border(
                width = 1.dp,
                brush = if (isPremium) {
                    Brush.linearGradient(
                        listOf(
                            Color(0xFFFFD700).copy(alpha = 0.8f),
                            Color(0xFFFF8C00).copy(alpha = 0.6f)
                        )
                    )
                } else {
                    Brush.linearGradient(
                        listOf(
                            if (isLowCredits) ErrorRed.copy(alpha = pulseAlpha) else NeonPurple.copy(alpha = 0.6f),
                            NeonPink.copy(alpha = 0.4f)
                        )
                    )
                },
                shape = RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = if (isPremium) "👑" else "⚡",
                fontSize = 14.sp
            )
            Text(
                text = if (isPremium) "PREMIUM" else "$credits",
                color = if (isPremium) Color(0xFFFFD700) else {
                    if (isLowCredits) ErrorRed else TextPrimary
                },
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
