package com.reina.chat.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.reina.chat.data.AdManager
import com.reina.chat.data.ChatMessage
import com.reina.chat.data.CreditsManager
import com.reina.chat.data.ReinaAI
import com.reina.chat.data.ReinaPersonality
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * ViewModel for the chat screen
 * Manages chat messages, credits, and ad interactions
 */
class ChatViewModel(application: Application) : AndroidViewModel(application) {
    
    private val creditsManager = CreditsManager(application)
    private val adManager = AdManager(application)
    
    // Chat messages state
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()
    
    // Credits state
    val credits: StateFlow<Int> = creditsManager.creditsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CreditsManager.INITIAL_CREDITS)
    
    // Premium status
    val isPremium: StateFlow<Boolean> = creditsManager.isPremiumFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    
    // First launch status
    val isFirstLaunch: StateFlow<Boolean> = creditsManager.isFirstLaunchFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    
    // UI states
    private val _isTyping = MutableStateFlow(false)
    val isTyping: StateFlow<Boolean> = _isTyping.asStateFlow()
    
    private val _showCreditsModal = MutableStateFlow(false)
    val showCreditsModal: StateFlow<Boolean> = _showCreditsModal.asStateFlow()
    
    private val _showPremiumModal = MutableStateFlow(false)
    val showPremiumModal: StateFlow<Boolean> = _showPremiumModal.asStateFlow()
    
    private val _adError = MutableStateFlow<String?>(null)
    val adError: StateFlow<String?> = _adError.asStateFlow()
    
    private val _showWelcome = MutableStateFlow(true)
    val showWelcome: StateFlow<Boolean> = _showWelcome.asStateFlow()
    
    init {
        // Preload ad
        adManager.loadRewardedAd()
        
        // Add initial greeting after a short delay
        viewModelScope.launch {
            delay(500)
            addReinaMessage(ReinaPersonality.getRandomGreeting())
        }
    }
    
    /**
     * Send a message from the user
     */
    fun sendMessage(content: String) {
        if (content.isBlank()) return
        
        viewModelScope.launch {
            val currentCredits = credits.value
            val premium = isPremium.value
            
            // Check if user has enough credits
            if (!premium && currentCredits < CreditsManager.CREDITS_PER_MESSAGE) {
                _showCreditsModal.value = true
                return@launch
            }
            
            // Use credits
            val success = creditsManager.useCredits()
            if (!success) {
                _showCreditsModal.value = true
                return@launch
            }
            
            // Add user message
            val userMessage = ChatMessage(
                content = content,
                isFromUser = true
            )
            _messages.value = _messages.value + userMessage
            
            // Show typing indicator
            _isTyping.value = true
            
            // Simulate Reina thinking and typing
            // Longer messages = longer typing time (more realistic)
            val baseTime = (800..1500).random().toLong()
            val extraTime = (content.length * 10).coerceAtMost(1500).toLong()
            delay(baseTime + extraTime)
            
            // Generate response using ReinaAI for smart responses
            val response = ReinaAI.generateResponse(content)
            _isTyping.value = false
            
            addReinaMessage(response)
            
            // Check for low credits warning
            val newCredits = credits.value
            if (!premium && newCredits in 1..3 && (0..2).random() == 0) {
                delay(1500)
                addReinaMessage(ReinaPersonality.lowCreditsWarning.random())
            }
        }
    }
    
    /**
     * Add a message from Reina with typing animation
     */
    private fun addReinaMessage(content: String) {
        val message = ChatMessage(
            content = content,
            isFromUser = false
        )
        _messages.value = _messages.value + message
    }
    
    /**
     * Watch an ad to earn credits
     */
    fun watchAd(activity: Activity) {
        adManager.showRewardedAd(
            activity = activity,
            onRewarded = {
                viewModelScope.launch {
                    creditsManager.addCreditsFromAd()
                    _showCreditsModal.value = false
                    
                    val responses = listOf(
                        "Nice! You got more credits! Let's keep the convo going! 🎉",
                        "Yay! More chat time together! 💜 Love that for us!",
                        "Credits acquired! 💪 Now where were we? Oh right, being awesome!",
                        "Woo! We're back in business! 🔥 What do you wanna talk about?"
                    )
                    addReinaMessage(responses.random())
                }
            },
            onAdDismissed = {
                // Ad was closed without reward
                viewModelScope.launch {
                    // Try to preload next ad
                    adManager.loadRewardedAd()
                }
            },
            onAdFailed = { error ->
                _adError.value = "Couldn't load ad. Try again!"
                viewModelScope.launch {
                    delay(3000)
                    _adError.value = null
                    // Try to load again
                    adManager.loadRewardedAd()
                }
            }
        )
    }
    
    /**
     * Show premium upgrade modal
     */
    fun showPremiumUpgrade() {
        _showPremiumModal.value = true
        _showCreditsModal.value = false
    }
    
    /**
     * Dismiss credits modal
     */
    fun dismissCreditsModal() {
        _showCreditsModal.value = false
    }
    
    /**
     * Dismiss premium modal
     */
    fun dismissPremiumModal() {
        _showPremiumModal.value = false
    }
    
    /**
     * Simulate premium purchase (for demo)
     * In production, integrate with Google Play Billing
     */
    fun purchasePremium() {
        viewModelScope.launch {
            creditsManager.activatePremium()
            _showPremiumModal.value = false
            _showCreditsModal.value = false
            
            val responses = listOf(
                "OMG you went premium! 👑 We can chat forever now! This is gonna be LEGENDARY! 🎮✨",
                "YESSS! Premium squad! 👑💜 You just unlocked unlimited Reina time! Best. Decision. Ever!",
                "You absolute LEGEND! 👑 No limits now! Let's make this the best chat experience ever!",
                "Welcome to the VIP club! 👑✨ I'm literally so excited we can talk without limits now!"
            )
            addReinaMessage(responses.random())
        }
    }
    
    /**
     * Complete welcome screen
     */
    fun completeWelcome() {
        viewModelScope.launch {
            creditsManager.completeFirstLaunch()
            _showWelcome.value = false
        }
    }
    
    /**
     * Check if ad is ready
     */
    fun isAdReady(): Boolean = adManager.isAdReady()
    
    /**
     * Preload ad
     */
    fun preloadAd() {
        adManager.loadRewardedAd()
    }
    
    /**
     * Clear chat history
     */
    fun clearChat() {
        viewModelScope.launch {
            _messages.value = emptyList()
            delay(300)
            addReinaMessage(ReinaPersonality.getRandomGreeting())
        }
    }
}
