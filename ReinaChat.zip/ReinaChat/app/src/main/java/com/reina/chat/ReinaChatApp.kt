package com.reina.chat

import android.app.Application
import com.google.android.gms.ads.MobileAds

/**
 * Reina Chat Application class
 * Initializes AdMob SDK on app start
 */
class ReinaChatApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize Mobile Ads SDK
        MobileAds.initialize(this) { }
    }
}
