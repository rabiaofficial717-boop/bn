package com.reina.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.reina.chat.ui.screens.ChatScreen
import com.reina.chat.ui.screens.WelcomeScreen
import com.reina.chat.ui.theme.ReinaChatTheme
import com.reina.chat.viewmodel.ChatViewModel

/**
 * Main Activity for Reina Chat
 * Handles navigation between Welcome and Chat screens
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        setContent {
            ReinaChatTheme {
                ReinaChatApp()
            }
        }
    }
}

@Composable
fun ReinaChatApp() {
    val chatViewModel: ChatViewModel = viewModel()
    val showWelcome by chatViewModel.showWelcome.collectAsState()
    val isFirstLaunch by chatViewModel.isFirstLaunch.collectAsState()
    
    // Show welcome screen on first launch or if explicitly set
    val shouldShowWelcome = showWelcome && isFirstLaunch
    
    AnimatedContent(
        targetState = shouldShowWelcome,
        transitionSpec = {
            if (targetState) {
                // Entering welcome screen
                fadeIn(animationSpec = androidx.compose.animation.core.tween(500)) togetherWith
                        fadeOut(animationSpec = androidx.compose.animation.core.tween(500))
            } else {
                // Leaving welcome screen -> Chat
                (slideInHorizontally(
                    initialOffsetX = { it },
                    animationSpec = androidx.compose.animation.core.tween(500)
                ) + fadeIn()) togetherWith
                        (slideOutHorizontally(
                            targetOffsetX = { -it },
                            animationSpec = androidx.compose.animation.core.tween(500)
                        ) + fadeOut())
            }
        },
        label = "screen_transition"
    ) { showingWelcome ->
        if (showingWelcome) {
            WelcomeScreen(
                onStartChat = {
                    chatViewModel.completeWelcome()
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            ChatScreen(
                viewModel = chatViewModel,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
