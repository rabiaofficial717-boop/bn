package com.reina.chat.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.reina.chat.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Stunning welcome screen with neon effects and gaming aesthetic
 */
@Composable
fun WelcomeScreen(
    onStartChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showContent by remember { mutableStateOf(false) }
    var showButton by remember { mutableStateOf(false) }
    
    LaunchedEffect(Unit) {
        delay(500)
        showContent = true
        delay(1000)
        showButton = true
    }
    
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Animated background effects
        NeonBackground()
        
        // Floating particles
        FloatingParticles()
        
        // Main content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Logo/Avatar with glow
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(800)) + scaleIn(
                    initialScale = 0.5f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                )
            ) {
                ReinaLogoLarge()
            }
            
            Spacer(modifier = Modifier.height(40.dp))
            
            // Title
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(800, delayMillis = 200)) + slideInVertically(
                    initialOffsetY = { 50 },
                    animationSpec = tween(600, delayMillis = 200)
                )
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "REINA",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimary,
                        letterSpacing = 8.sp
                    )
                    
                    GradientText(
                        text = "Your AI Companion",
                        gradient = listOf(NeonPink, NeonPurple),
                        fontSize = 18.sp
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Tagline
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(600, delayMillis = 400))
            ) {
                Text(
                    text = "Bold. Stylish. Unapologetically Confident.",
                    color = TextMuted,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 24.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(60.dp))
            
            // Start button
            AnimatedVisibility(
                visible = showButton,
                enter = fadeIn(tween(500)) + scaleIn(
                    initialScale = 0.8f,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioMediumBouncy,
                        stiffness = Spring.StiffnessLow
                    )
                )
            ) {
                NeonButton(
                    text = "Start Chatting",
                    onClick = onStartChat
                )
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Credits info
            AnimatedVisibility(
                visible = showButton,
                enter = fadeIn(tween(500, delayMillis = 200))
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚡ ",
                        fontSize = 14.sp
                    )
                    Text(
                        text = "10 Free Credits to Start",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * Animated neon background with gradient waves
 */
@Composable
private fun NeonBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "bg")
    val offset1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset1"
    )
    val offset2 by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(25000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset2"
    )
    
    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .blur(80.dp)
            .alpha(0.6f)
    ) {
        // First glow orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonPurple.copy(alpha = 0.4f),
                    NeonPurple.copy(alpha = 0.1f),
                    Color.Transparent
                ),
                center = Offset(
                    x = size.width * 0.3f + cos(Math.toRadians(offset1.toDouble())).toFloat() * 100f,
                    y = size.height * 0.3f + sin(Math.toRadians(offset1.toDouble())).toFloat() * 100f
                ),
                radius = size.width * 0.5f
            ),
            center = Offset(
                x = size.width * 0.3f + cos(Math.toRadians(offset1.toDouble())).toFloat() * 100f,
                y = size.height * 0.3f + sin(Math.toRadians(offset1.toDouble())).toFloat() * 100f
            ),
            radius = size.width * 0.5f
        )
        
        // Second glow orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonPink.copy(alpha = 0.3f),
                    NeonPink.copy(alpha = 0.1f),
                    Color.Transparent
                ),
                center = Offset(
                    x = size.width * 0.7f + cos(Math.toRadians(offset2.toDouble())).toFloat() * 80f,
                    y = size.height * 0.7f + sin(Math.toRadians(offset2.toDouble())).toFloat() * 80f
                ),
                radius = size.width * 0.4f
            ),
            center = Offset(
                x = size.width * 0.7f + cos(Math.toRadians(offset2.toDouble())).toFloat() * 80f,
                y = size.height * 0.7f + sin(Math.toRadians(offset2.toDouble())).toFloat() * 80f
            ),
            radius = size.width * 0.4f
        )
    }
}

/**
 * Floating particles effect
 */
@Composable
private fun FloatingParticles() {
    val particles = remember {
        (0..30).map {
            Particle(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                size = Random.nextFloat() * 4f + 1f,
                speed = Random.nextFloat() * 0.5f + 0.1f,
                alpha = Random.nextFloat() * 0.5f + 0.2f
            )
        }
    }
    
    val infiniteTransition = rememberInfiniteTransition(label = "particles")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time"
    )
    
    Canvas(modifier = Modifier.fillMaxSize()) {
        particles.forEach { particle ->
            val yOffset = ((particle.y + time * particle.speed) % 1f)
            drawCircle(
                color = NeonPink.copy(alpha = particle.alpha),
                radius = particle.size.dp.toPx(),
                center = Offset(
                    x = particle.x * size.width,
                    y = yOffset * size.height
                )
            )
        }
    }
}

private data class Particle(
    val x: Float,
    val y: Float,
    val size: Float,
    val speed: Float,
    val alpha: Float
)

/**
 * Large Reina logo with animated glow
 */
@Composable
private fun ReinaLogoLarge() {
    val infiniteTransition = rememberInfiniteTransition(label = "logo")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    
    Box(
        modifier = Modifier.size(160.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer glow ring
        Canvas(
            modifier = Modifier
                .size(160.dp)
                .scale(glowScale)
        ) {
            drawCircle(
                brush = Brush.sweepGradient(
                    0f to NeonPurple.copy(alpha = 0.1f),
                    0.25f to NeonPink.copy(alpha = 0.4f),
                    0.5f to NeonPurple.copy(alpha = 0.1f),
                    0.75f to NeonBlue.copy(alpha = 0.4f),
                    1f to NeonPurple.copy(alpha = 0.1f)
                ),
                radius = size.minDimension / 2
            )
        }
        
        // Main avatar
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            NeonPink.copy(alpha = 0.5f),
                            NeonPurple.copy(alpha = 0.4f)
                        )
                    )
                )
                .border(
                    width = 3.dp,
                    brush = Brush.linearGradient(listOf(NeonPink, NeonPurple, NeonBlue)),
                    shape = RoundedCornerShape(32.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "R",
                fontSize = 56.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
        }
    }
}

/**
 * Gradient text component
 */
@Composable
private fun GradientText(
    text: String,
    gradient: List<Color>,
    fontSize: androidx.compose.ui.unit.TextUnit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "text")
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "offset"
    )
    
    Text(
        text = text,
        fontSize = fontSize,
        fontWeight = FontWeight.SemiBold,
        style = androidx.compose.ui.text.TextStyle(
            brush = Brush.linearGradient(
                colors = gradient + gradient.first(),
                start = Offset(offset * 500f, 0f),
                end = Offset(offset * 500f + 200f, 0f)
            )
        )
    )
}

/**
 * Neon styled button with gaming aesthetic
 */
@Composable
private fun NeonButton(
    text: String,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "button")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )
    
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        NeonPurple.copy(alpha = glowAlpha),
                        NeonPink.copy(alpha = glowAlpha)
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.linearGradient(listOf(NeonPink, NeonPurple)),
                shape = RoundedCornerShape(28.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 48.dp, vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}
