package com.reina.chat.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

// DataStore extension
private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "reina_settings")

/**
 * Manages user credits and premium status using DataStore
 */
class CreditsManager(private val context: Context) {
    
    companion object {
        private val CREDITS_KEY = intPreferencesKey("credits")
        private val IS_PREMIUM_KEY = booleanPreferencesKey("is_premium")
        private val TOTAL_MESSAGES_KEY = intPreferencesKey("total_messages")
        private val FIRST_LAUNCH_KEY = booleanPreferencesKey("first_launch")
        
        const val INITIAL_CREDITS = 10
        const val CREDITS_PER_MESSAGE = 3
        const val CREDITS_FROM_AD = 5
    }
    
    // Flow of current credits
    val creditsFlow: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[CREDITS_KEY] ?: INITIAL_CREDITS
    }
    
    // Flow of premium status
    val isPremiumFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[IS_PREMIUM_KEY] ?: false
    }
    
    // Flow of total messages sent
    val totalMessagesFlow: Flow<Int> = context.dataStore.data.map { preferences ->
        preferences[TOTAL_MESSAGES_KEY] ?: 0
    }
    
    // Check if first launch
    val isFirstLaunchFlow: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[FIRST_LAUNCH_KEY] ?: true
    }
    
    /**
     * Use credits when sending a message
     * Returns true if successful, false if not enough credits
     */
    suspend fun useCredits(): Boolean {
        var success = false
        context.dataStore.edit { preferences ->
            val currentCredits = preferences[CREDITS_KEY] ?: INITIAL_CREDITS
            val isPremium = preferences[IS_PREMIUM_KEY] ?: false
            
            if (isPremium) {
                // Premium users don't use credits
                success = true
            } else if (currentCredits >= CREDITS_PER_MESSAGE) {
                preferences[CREDITS_KEY] = currentCredits - CREDITS_PER_MESSAGE
                success = true
            }
            
            // Increment total messages
            if (success) {
                val totalMessages = preferences[TOTAL_MESSAGES_KEY] ?: 0
                preferences[TOTAL_MESSAGES_KEY] = totalMessages + 1
            }
        }
        return success
    }
    
    /**
     * Add credits from watching an ad
     */
    suspend fun addCreditsFromAd() {
        context.dataStore.edit { preferences ->
            val currentCredits = preferences[CREDITS_KEY] ?: 0
            preferences[CREDITS_KEY] = currentCredits + CREDITS_FROM_AD
        }
    }
    
    /**
     * Activate premium status
     */
    suspend fun activatePremium() {
        context.dataStore.edit { preferences ->
            preferences[IS_PREMIUM_KEY] = true
        }
    }
    
    /**
     * Reset credits (for testing)
     */
    suspend fun resetCredits() {
        context.dataStore.edit { preferences ->
            preferences[CREDITS_KEY] = INITIAL_CREDITS
        }
    }
    
    /**
     * Mark first launch as complete
     */
    suspend fun completeFirstLaunch() {
        context.dataStore.edit { preferences ->
            preferences[FIRST_LAUNCH_KEY] = false
        }
    }
}
